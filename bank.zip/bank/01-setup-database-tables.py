# Databricks notebook source
CATALOG_NAME = "demo"
SCHEMA_NAME = "bank"
FOLDER_NAME = "data"

# COMMAND ----------

# %sql
# CREATE DATABASE IF NOT EXISTS demo.bank;
# USE demo.bank;

spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME}")
spark.sql(f"USE {CATALOG_NAME}.{SCHEMA_NAME}")

# COMMAND ----------

# %sql
# CREATE OR REPLACE TABLE customer AS
# SELECT *
# FROM read_files(
#   "/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/CUSTOMER.csv",
#   format => 'csv',
#   header => true,
#   inferSchema => true
# );

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/CUSTOMER.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("customer") # the default format is delta
# df.write.format("delta").mode("ignore").saveAsTable("customer2")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CUSTOMER
# MAGIC LIMIT 10

# COMMAND ----------

df = spark.sql("SELECT * FROM CUSTOMER LIMIT 10")
# df.show(1000000)

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED demo.bank.customer;

# COMMAND ----------

# spark.sql("""
# INSERT INTO CUSTOMER (client_id, first_name, last_name, open_account_date, dob, preferred_language, employment_type, occupation, postal_code, province, branch_key, education_degree)
# VALUES (1, 'John', 'Doe', '2025-10-08', '1990-01-01', 'English', 'Full-time', 'Engineer', '12345', 'ON', 1, 'Bachelor')
# """)
# display(spark.sql("SELECT * FROM CUSTOMER WHERE client_id = 1"))
# spark.sql("DELETE FROM CUSTOMER WHERE client_Id = 1")

# COMMAND ----------

df = spark.read.csv(
    f'/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/ACCOUNT.csv',
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("account")

# COMMAND ----------

df = spark.sql("SELECT * FROM account")
display(df)

# COMMAND ----------

df = spark.read.csv(
    f'/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/BRANCH.csv',
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("branch")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM branch

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/BUSINESS_UNIT.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("business_unit")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("clientid_account_number_x_ref_table")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/MERCHANT.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("merchant")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/MERCHANT_SERVICE_CATEGORY.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("merchant_service_category")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/PRODUCT.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("product")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/BRANCH.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("branch")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/demo/bank/data/TRANSACTION_STATUS.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("transaction_status")

# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-01-2022-1.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_01_2022_1")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-02-2022-2.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_02_2022_2")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-03-2022-3.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_03_2022_3")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-04-2022-4.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_04_2022_4")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-05-2022-5.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_05_2022_5")


# COMMAND ----------

df = spark.read.csv(
    f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{FOLDER_NAME}/txn-06-2022-6.csv",
    header=True,
    inferSchema=True
)

# "ignore" means: do nothing if the table already exists
df.write.mode("ignore").saveAsTable("txn_06_2022_6")


# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES;