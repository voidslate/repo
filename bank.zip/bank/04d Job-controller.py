# Databricks notebook source
# Note: the second parameter is time_out in seconds
dbutils.notebook.run('./04b Job-ingest', 60)
dbutils.notebook.run('./04c Job-display', 60)