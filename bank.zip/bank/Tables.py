# Databricks notebook source
# MAGIC %md
# MAGIC ## SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC USE demo.sales;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the table with order_id as numeric
# MAGIC CREATE TABLE sales_orders (
# MAGIC   order_id     INT,
# MAGIC   customer_name  STRING,
# MAGIC   order_total  DECIMAL(10,2)
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert sample rows
# MAGIC INSERT INTO sales_orders (order_id, customer_name, order_total)
# MAGIC VALUES
# MAGIC   (1, 'CUST1001', 250.75),
# MAGIC   (2, 'CUST1002', 99.99),
# MAGIC   (3, 'CUST1003', 480.50);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Select all rows
# MAGIC SELECT * 
# MAGIC FROM sales_orders;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Drop the table
# MAGIC DROP TABLE sales_orders;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Python

# COMMAND ----------

from decimal import Decimal
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DecimalType

schema = StructType([
    StructField("order_id", IntegerType(), True),
    StructField("customer_name", StringType(), True),
    StructField("order_total", DecimalType(10,2), True)
])

data = [
    (1, "CUST1001", Decimal("250.75")),
    (2, "CUST1002", Decimal("99.99")),
    (3, "CUST1003", Decimal("480.50"))
]

df = spark.createDataFrame(data, schema=schema)

# 3. Save as a table (managed by default unless you specify a path)
df.write.mode("overwrite").saveAsTable("sales_orders")

# 4. Query the table back into a DataFrame
df2 = spark.table("sales_orders").filter("order_total > 100")
display(df2)

# 5. Drop the table
spark.sql("DROP TABLE sales_orders")