# Databricks notebook source
CATALOG_NAME = "demo"
SOURCE_SCHEMA_NAME = "bank"
NEW_SCHEMA_NAME = "bank2" # note: change 2 to your student id

# COMMAND ----------

spark.sql(f"DROP DATABASE IF EXISTS {CATALOG_NAME}.{NEW_SCHEMA_NAME} CASCADE;")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG_NAME}.{NEW_SCHEMA_NAME};")
spark.sql(f"USE {CATALOG_NAME}.{NEW_SCHEMA_NAME};")

# COMMAND ----------

spark.sql(f"""
CREATE TABLE {CATALOG_NAME}.{NEW_SCHEMA_NAME}.TXN AS
SELECT
  *
FROM
  {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.txn_01_2022_1
""")  

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Ensure the TXN table exists
# MAGIC SELECT * FROM TXN