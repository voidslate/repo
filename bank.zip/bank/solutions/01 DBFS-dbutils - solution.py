# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 01 - Working with DBFS/dbutils
# MAGIC
# MAGIC In this lab, you will use dbutils to perform various DBFS operations. The operations includes:
# MAGIC
# MAGIC - Get dbutils help
# MAGIC - Explore dbutils operations
# MAGIC - Getting the mount list
# MAGIC - Use the fs object to manipulate files and directories
# MAGIC
# MAGIC Most cells will only ask you to execute the readymade scripts. Wherever you see TODO, it means you are required to type script from scratch and meant the requirement mentioned in the cell.

# COMMAND ----------

# Execute the script to get dbutils help
dbutils.help()

# COMMAND ----------

# execute the cell to get the DbfsUtils object details
dbutils.fs.help()

# COMMAND ----------

# Execute the cell to get the ls command details
dbutils.fs.help("ls")

# COMMAND ----------

# TODO: Type the command here to get help for the cp command

dbutils.fs.help("cp")

# COMMAND ----------

# Mount points are external locations, such as Azure Data Lake Storage (ADLS) that resides outside of the Azure Databricks cluster. This way data can be decoupled from the processing portion (Databricks). You can have data hosted in other places, such as AWS S3 as well.
# Execue the cell to get the list of mounts available in the Azure Databricks lab environment. You will note the output isn't wellformatted.
dbutils.fs.mounts()

# COMMAND ----------

# Execue the cell to get the list of mounts available in the Azure Databricks lab environment. You will note the output IS wellformatted.
display(dbutils.fs.mounts())

# COMMAND ----------

# In the lab environment, /user/hive/warehouse is where the database physical files reside in the PARQUET format. This location can also be used to store CSV files.
# Execute the cell to see the list of databases available to you in the lab environment. Notice the output isn't formatted
dbutils.fs.ls("/user/hive/warehouse")

# COMMAND ----------

# The output from the previous command wasn't well-formatted. Run the command again with the display function 
display(dbutils.fs.ls("/user/hive/warehouse"))

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execuet this "SQL" cell to get the actual list of databases and notice the webagetraining_sandbox_db is displayed like it was listed as part of the dbutils.fs.ls command 
# MAGIC SHOW DATABASES

# COMMAND ----------

# Execute the cell to create a directory. Don't forget to replace {STUDENT_ID} with the unique value assigned to you so there is no clash since you are all sharing the same lab environment
dbutils.fs.mkdirs("/data/{STUDENT_ID")

# COMMAND ----------

# TODO:
# You are tasked to create a log file. Under the newly created directory, create a file named log.txt with "Hello world!" as the file contents
# HINT: Get the command help for the "put" dbutils.fs object

dbutils.fs.put("/data/{STUDENT_ID}/log.txt", "Hello world!")

# COMMAND ----------

# Execuete the cell to read the first 5 bytes of the log.txt file. Don't forget to replace {STUDENT_ID} with the value assigned to you. Ensure "Hello" is displayed
dbutils.fs.head("/data/{STUDENT_ID}/log.txt",5)

# COMMAND ----------

# TODO: Type and execute the command to create a copy of the log.txt with the file name of message.txt
# HINT: Get the command help for cp

dbutils.fs.cp("/data/{STUDENT_ID}/log.txt", "/data/{STUDENT_ID}/message.txt")

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Exercise
# MAGIC
# MAGIC In the realworld scenario, you store CSV files in the form of folders and sub-folders to partition data. This way rather than reading all CSV files, you can read files in small chunks by year and month. You can choose to create more granular levels, such as quarter, week, and day
# MAGIC
# MAGIC In this exercise, you are tasked to create the folder structure that involves year, month, and day like this:
# MAGIC /data/{STUDENT_ID}/financial-data/YEAR=2022/MONTH=JUN
# MAGIC
# MAGIC Write code in the cell below to create the nested folder structure for years 2020 to 2022 with all months from JAN to DEC under each folder for year 

# COMMAND ----------

# MAGIC %py
# MAGIC # TODO: Write your code here to accomplish the requirements mentioned in the above cell
# MAGIC years = [2020, 2021, 2022]
# MAGIC months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
# MAGIC
# MAGIC for y in years:
# MAGIC     print(y)
# MAGIC     for m in months:
# MAGIC         dbutils.fs.mkdirs("/data/{STUDENT_ID}/YEAR=%d/MONTH=%s"%(y, m))
# MAGIC         print(m)
# MAGIC     print()

# COMMAND ----------

# Verify the nested directory structure exists
dbutils.fs.ls("/data/{STUDENT_ID}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Clean-up

# COMMAND ----------

# CLEAN-UP: 
# Replace {STUDENT_ID} with the value assigned to you and execute the script to recursively delete the folder and files you created earlier in this lab.
# WARNING: Ensure you type the STUDENT_ID properly, otherwise you will end up deleting someone else's directory.
dbutils.fs.rm("/{STUDENT_ID}", True)