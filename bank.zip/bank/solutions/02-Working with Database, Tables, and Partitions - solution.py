# Databricks notebook source
# MAGIC %md
# MAGIC # Working with Databases, Tables, Views, and Partitions
# MAGIC
# MAGIC In this lab, you will see how to create and work with the following:  
# MAGIC
# MAGIC
# MAGIC - Databases
# MAGIC - Tables
# MAGIC   - In the realworld scenario, you will create tables from Azure Syanpse using jdbc or from CSV files uploaded to the Azure Databricks workspace.These techniques will be partially demonstrated by the instructor but they are not included in the lab. The lab covers how to create a table from an existing database and includes creation of a table from a CSV file as reference. 
# MAGIC   - The lab also covers partitioned tables.
# MAGIC
# MAGIC - Creating a database per attendee is required so that it creates an isolation-level and avoids having clashes with each others work. At the same time, we don't want to create too many tables and views since that consumes resources that translates to getting billed for using the services. That is why, we will keep this lab to the bare-minimum.
# MAGIC > Note: Views, Temporary tables/views will be covered in the next part of the lab. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 1: Creating a Database and Tables

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute this cell to see how many tables we have in the sample database. Later in the lab, you will create a custom database and then copy over some of these tables into the newly created database.
# MAGIC USE webagetraining_sandbox_db;
# MAGIC SHOW TABLES;

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Create a database and switch to it.
# MAGIC -- NOTE: Change {STUDENT_ID} with the value assigned to you.
# MAGIC -- The reason we are creating a new database is, we want to explore some features, such as creating views that
# MAGIC CREATE DATABASE `{STUDENT_ID}`;
# MAGIC USE `{STUDENT_ID}`;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the cell to verify the database was created successfully
# MAGIC SHOW DATABASES

# COMMAND ----------

# In the previous cell, you used SQL to view the database list. In this cell, you will see how to use PySpark/Spark SQL to do the same thing
display(spark.sql("SHOW DATABASES"))

# COMMAND ----------

# MAGIC %sql -- In this part, you will create CUSTOMER table from the existing sample database. We are creating a copy of the database since we want to later add partitions and views. Since, all attendees are sharing the same lab environment, we don't to have any clash. Therefore, you are working on the isolated databases.
# MAGIC CREATE TABLE BRANCH AS
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   webagetraining_sandbox_db.CUSTOMER

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute this cell to verify you can query the CUSTOMER table in the new custom database. Don't forget to replace {STUDENT_ID} with the value assigned to you. You will only query the first 10 records since we only want to verify the table exists rather than fetching all records an cause unnencessary overhead on resources
# MAGIC -- Note: You don't really need to prefix the CUSTOMER table with the database name since you have already used the "USE" keyword earlier in the lab. Still, to double-check that you are not querying the CUSTOMER table in the original webagetraining_sandbox_db database, the prefix is added
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   `{STUDENT_ID}`.BRANCH
# MAGIC limit
# MAGIC   10;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TODO: Add code here to create a table TRANSACTION_TABLE from the txn_01_2022_1 table available in the sample database.
# MAGIC

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- verify the TRANSACTION table exists.
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   TRANSACTION_TABLE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the cell to get the table list and verify you have CUSTOMER, TRANSACTION_TABLE, and MERCHANT tables in the custom database
# MAGIC SHOW TABLES;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- CLEAN-UP: Execute the following scripts to clean up the tables you created in the lab.
# MAGIC DROP TABLE CUSTOMER;
# MAGIC DROP TABLE TRANSACTION_TABLE;
# MAGIC DROP TABLE MERCHANT;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 2: Working with Partitioning

# COMMAND ----------

# MAGIC %md
# MAGIC #### Question: Can you suggest what column should be used to partition the BRANCH table?
# MAGIC > Write down your answer here
# MAGIC - `ANSWER`: {YOUR_ANSWER}

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- create the BRANCH table and partition it by branch_location_city
# MAGIC DROP TABLE IF EXISTS `{STUDENT_ID}`.BRANCH;
# MAGIC
# MAGIC CREATE TABLE `{STUDENT_ID}`.BRANCH (
# MAGIC   branch_key INT,
# MAGIC   branch_location_city STRING,
# MAGIC   branch_manager_first_name STRING,
# MAGIC   branch_manager_last_name STRING,
# MAGIC   number_of_staff INT,
# MAGIC   start_date_branch DATE,
# MAGIC   end_date_branch DATE,
# MAGIC   province STRING
# MAGIC ) PARTITIONED BY(branch_location_city);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- insert record into the table. Since partitions are defined, data will be inserted into the approriate buckets/partitions.
# MAGIC INSERT INTO `{STUDENT_ID}`.BRANCH SELECT * FROM webagetraining_sandbox_db.BRANCH

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute the command and notice the partitions in the BRANCH table.
# MAGIC SHOW PARTITIONS `{STUDENT_ID}`.BRANCH

# COMMAND ----------

# Execute the following script to partition the MERCHANT table in webagetraining_sandbox_db and save it as partitioned table.
df = spark.read.table("`webagetraining_sandbox_db`.MERCHANT")
df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy("service_category_key").saveAsTable("`{STUDENT_ID}`.MERCHANT")

# COMMAND ----------

# MAGIC %md
# MAGIC # Clean-Up

# COMMAND ----------

# MAGIC %sql
# MAGIC -- CLEAN-UP: Execute the cell the drop the database and its objects. Don't forget to replace {STUDENT_ID} with the value assigned to you
# MAGIC DROP DATABASE `{STUDENT_1}` CASCADE