# Databricks notebook source
# MAGIC %md
# MAGIC # Project
# MAGIC
# MAGIC ## Read through the scenarios and write SQL or PySpark code to answer the question. Time-permitting, you can attempt the questions both in SQL and PySpark.
# MAGIC > Add cells below each question to implement the solution.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pre-requisite: Switch to the Training Database

# COMMAND ----------

# MAGIC %sql
# MAGIC USE webagetraining_sandbox_db

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 1: Answer the following two parts:
# MAGIC - Write a query to display all customers (id, name, and branch location city). Order the customers by client id.
# MAGIC - Visualize the table as Pie Chart breaking down customer count by branch location city.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   c.client_id,
# MAGIC   c.first_name, c.last_name,
# MAGIC   b.branch_location_city
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC ORDER BY
# MAGIC   c.client_id

# COMMAND ----------

df_customer = spark.read.table("CUSTOMER")
df_branch = spark.read.table("BRANCH")

df = df_customer \
    .join(df_branch, df_customer.branch_key == df_branch.branch_key, "inner") \
    .select("client_id", "first_name", "last_name", "branch_location_city") \
    .orderBy("client_id")

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 2: List customers (id, name, branch location, account type name) who have opened the TFSA account. Sort data by client_id

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   c.client_id,
# MAGIC   c.first_name,
# MAGIC   c.last_name,
# MAGIC   b.branch_location_city,
# MAGIC   a.account_type_name
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC WHERE a.account_type_name LIKE '%TFSA%'
# MAGIC ORDER BY c.client_id

# COMMAND ----------

from pyspark.sql.functions import col, desc


df_customer = spark.read.table("CUSTOMER")
df_xref = spark.read.table("CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE")
df_branch = spark.read.table("BRANCH")
df_account = spark.read.table("ACCOUNT")

df = df_customer \
  .join(df_xref, df_customer.client_id == df_xref.client_id, "inner") \
  .join(df_branch, df_branch.branch_key == df_customer.branch_key) \
  .join(df_account, df_xref.account_key == df_account.account_key) \
  .filter(df_account.account_type_name.like("%TFSA%")) \
  .orderBy(df_customer.client_id) \
  .select(df_customer.client_id, df_customer.first_name, df_customer.last_name, df_branch.branch_location_city, df_account.account_type_name)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 3: Write a query to retrieve and display the branch location (city) where the most number of TFSA Savings Account are opened by customers.

# COMMAND ----------

# MAGIC %sql -- Write a query to retrieve and display the branch location (city) where the most number of TFSA Savings Account are opened by customers.
# MAGIC SELECT
# MAGIC   b.branch_location_city,
# MAGIC   COUNT(c.client_id)
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC WHERE a.account_type_name LIKE '%TFSA%'
# MAGIC GROUP BY
# MAGIC   b.branch_location_city
# MAGIC ORDER BY
# MAGIC   count(c.client_id) DESC
# MAGIC LIMIT
# MAGIC   1;

# COMMAND ----------

from pyspark.sql.functions import desc

df_customer = spark.read.table("CUSTOMER")
df_xref = spark.read.table("CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE")
df_branch = spark.read.table("BRANCH")
df_account = spark.read.table("ACCOUNT")

df = df_customer \
  .join(df_xref, df_customer.client_id == df_xref.client_id, "inner") \
  .join(df_branch, df_branch.branch_key == df_customer.branch_key) \
  .join(df_account, df_xref.account_key == df_account.account_key) \
  .filter(df_account.account_type_name.like("%TFSA%")) \
  .groupBy(df_branch.branch_location_city).count() \
  .orderBy(desc("count")) \
  .limit(1)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 4: Write a query to retrieve and display the province where most customers own a credit card.

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT
# MAGIC   c.province,
# MAGIC   COUNT(c.client_id) AS client_count
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC   INNER JOIN BUSINESS_UNIT bu ON a.business_unit_key = bu.business_unit_key
# MAGIC WHERE
# MAGIC   bu.unit_name = 'Credit Cards'
# MAGIC GROUP BY
# MAGIC   c.province
# MAGIC ORDER BY
# MAGIC   client_count DESC
# MAGIC LIMIT
# MAGIC   1

# COMMAND ----------

from pyspark.sql.functions import desc

df_customer = spark.read.table("CUSTOMER")
df_xref = spark.read.table("CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE")
df_account = spark.read.table("ACCOUNT")
df_business_unit = spark.read.table("BUSINESS_UNIT")

df = df_customer \
  .join(df_xref, df_customer.client_id == df_xref.client_id, "inner") \
  .join(df_account, df_account.account_key == df_xref.account_key) \
  .join(df_business_unit, df_account.business_unit_key == df_business_unit.business_unit_key) \
  .filter(df_business_unit.unit_name == 'Credit Cards') \
  .groupBy(df_customer.province).count() \
  .orderBy(desc("count")) \
  .limit(1)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 5: Name the bank whose Visa Card is most popular in terms of sales amount in the txn_01_2022_1 table

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT
# MAGIC   m.merchant_name,
# MAGIC   SUM(txn.amount) AS total_amount
# MAGIC FROM
# MAGIC   MERCHANT m
# MAGIC   INNER JOIN txn_01_2022_1 txn ON m.merchant_key = txn.merchant_key
# MAGIC   INNER JOIN MERCHANT_SERVICE_CATEGORY msc ON m.service_category_key = msc.service_category_key
# MAGIC   INNER JOIN ACCOUNT a ON a.account_key = txn.account_key
# MAGIC   INNER JOIN PRODUCT p ON p.product_key = a.product_key
# MAGIC WHERE
# MAGIC   p.product_name = 'Visa Card'
# MAGIC   AND msc.service_category_name = 'Banking Services'
# MAGIC GROUP BY
# MAGIC   m.merchant_name
# MAGIC ORDER BY
# MAGIC   total_amount DESC
# MAGIC LIMIT 1

# COMMAND ----------

from pyspark.sql.functions import desc

df_account = spark.read.table("ACCOUNT")
df_merchant = spark.read.table("MERCHANT")
df_txn = spark.read.table("txn_01_2022_1")
df_merchant_service_category = spark.read.table("MERCHANT_SERVICE_CATEGORY")
df_product = spark.read.table("PRODUCT")

df = df_merchant \
  .join(df_txn, df_merchant.merchant_key == df_txn.merchant_key, "inner") \
  .join(df_merchant_service_category, df_merchant_service_category.service_category_key == df_merchant.service_category_key) \
  .join(df_account, df_account.account_key == df_txn.account_key) \
  .join(df_product, df_product.product_key == df_account.product_key) \
  .filter((df_product.product_name == 'Visa Card') & (df_merchant_service_category.service_category_name == 'Banking Services'))  \
  .groupBy(df_merchant.merchant_name) \
  .sum("amount") \
  .orderBy(desc("sum(amount)")) \
  .limit(1)
  
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 6: Answer the following two parts:
# MAGIC - Retrieve and display the 5 branches where the least number of accounts are opened by customers
# MAGIC - Visualize the output as Bar Chart breaking down customer count by branch location city.

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT
# MAGIC   b.branch_location_city,
# MAGIC   COUNT(c.client_id) AS client_count
# MAGIC FROM
# MAGIC   BRANCH b
# MAGIC   INNER JOIN CUSTOMER c ON b.branch_key = c.branch_key
# MAGIC GROUP BY
# MAGIC   b.branch_location_city
# MAGIC ORDER BY
# MAGIC   client_count
# MAGIC LIMIT
# MAGIC   5

# COMMAND ----------

df_customer = spark.read.table("CUSTOMER")
df_branch = spark.read.table("BRANCH")

df = df_branch \
  .join(df_customer, df_branch.branch_key == df_customer.branch_key, "inner") \
  .groupBy(df_branch.branch_location_city).count() \
  .orderBy("count") \
  .limit(5)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 7: Answer the following two parts:
# MAGIC - Based on the transaction amount, list 5 debit based products that are least utilized by customers.
# MAGIC - Visualize data using Area Chart breaking down product name by total amount.

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC SELECT
# MAGIC   p.product_name,
# MAGIC   SUM(txn.amount) AS total_amount
# MAGIC FROM
# MAGIC   ACCOUNT a
# MAGIC   INNER JOIN txn_01_2022_1 txn ON a.account_key = txn.account_key
# MAGIC   INNER JOIN PRODUCT p ON p.product_key = a.product_key
# MAGIC WHERE
# MAGIC   txn.dc = 'debit'
# MAGIC GROUP BY
# MAGIC   p.product_name
# MAGIC ORDER BY
# MAGIC   total_amount
# MAGIC LIMIT
# MAGIC   5

# COMMAND ----------

df_account = spark.read.table("ACCOUNT")
df_txn = spark.read.table("txn_01_2022_1")
df_product = spark.read.table("PRODUCT")

df = df_account \
  .join(df_txn, df_account.account_key == df_txn.account_key, "inner") \
  .join(df_product, df_product.product_key == df_account.product_key) \
  .filter(df_txn.dc == 'debit') \
  .groupBy(df_product.product_name).sum("amount") \
  .orderBy("sum(amount)") \
  .limit(5)

df.display()