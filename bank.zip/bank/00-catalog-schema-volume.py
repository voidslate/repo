# Databricks notebook source
# MAGIC %sql
# MAGIC SHOW CATALOGS

# COMMAND ----------

# MAGIC %sql
# MAGIC --USE demo.bank;
# MAGIC SHOW SCHEMAS -- SHOW DATABASES

# COMMAND ----------

# MAGIC %sql
# MAGIC USE demo.bank;
# MAGIC SHOW VOLUMES;

# COMMAND ----------

# MAGIC %sql
# MAGIC LIST '/Volumes/demo/bank/data'

# COMMAND ----------

# List all files in a volume
files = dbutils.fs.ls("/Volumes/demo/bank/data")
display(files)   # pretty table in a notebook

# COMMAND ----------

# MAGIC %sql
# MAGIC USE demo.bank;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_catalog()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_schema()