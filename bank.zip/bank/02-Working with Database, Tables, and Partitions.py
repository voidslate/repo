# Databricks notebook source
# MAGIC %md
# MAGIC # Working with Databases, Tables, Views, and Partitions
# MAGIC
# MAGIC In this lab, you will see how to create and work with the following:  
# MAGIC
# MAGIC
# MAGIC - Databases
# MAGIC - Tables
# MAGIC   - In the realworld scenario, you will create tables from Azure Syanpse using jdbc or from CSV files uploaded to the Azure Databricks workspace.These techniques will be partially demonstrated by the instructor but they are not included in the lab. The lab covers how to create a table from an existing database and includes creation of a table from a CSV file as reference. 
# MAGIC   - The lab also covers partitioned tables.
# MAGIC
# MAGIC - Creating a database per attendee is required so that it creates an isolation-level and avoids having clashes with each others work. At the same time, we don't want to create too many tables and views since that consumes resources that translates to getting billed for using the services. That is why, we will keep this lab to the bare-minimum.
# MAGIC > Note: Views, Temporary tables/views will be covered in the next part of the lab. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 1: Creating a Database and Tables

# COMMAND ----------

CATALOG_NAME = "demo"
SOURCE_SCHEMA_NAME = "bank"
NEW_SCHEMA_NAME = "bank_2" # Note change 2 to your student id


# COMMAND ----------

# Execute this cell to see how many tables we have in the sample database. Later in the lab, you will create a custom database and then copy over some of these tables into the newly created database.
spark.sql(f"USE {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}")
spark.sql("SHOW TABLES");

# COMMAND ----------

# Create a database and switch to it.
# The reason we are creating a new database is, we want to explore some features, such as creating views and partitioning.
# You will drop the schema after exploring the features
spark.sql(f"DROP SCHEMA IF EXISTS {NEW_SCHEMA_NAME} CASCADE")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {NEW_SCHEMA_NAME}")
spark.sql(f"USE {NEW_SCHEMA_NAME}")


# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the cell to verify the database was created successfully
# MAGIC SHOW DATABASES

# COMMAND ----------

# In the previous cell, you used SQL to view the database list. In this cell, you will see how to use PySpark/Spark SQL to do the same thing
display(spark.sql("SHOW DATABASES"))

# COMMAND ----------

# create a table TRANSACTION_TABLE from the txn_01_2022_1 table available in the sample database.
spark.sql(f"""
CREATE TABLE TRANSACTION_TABLE AS
SELECT
  *
FROM
  {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.txn_01_2022_1
""")  

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- verify the TRANSACTION table exists.
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   TRANSACTION_TABLE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the cell to get the table list and verify you have CUSTOMER, TRANSACTION_TABLE, and MERCHANT tables in the custom database
# MAGIC SHOW TABLES;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 2: Working with Partitioning

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_schema()

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- create the BRANCH table and partition it by branch_location_city
# MAGIC DROP TABLE IF EXISTS BRANCH;
# MAGIC
# MAGIC CREATE TABLE BRANCH (
# MAGIC   branch_key INT,
# MAGIC   branch_location_city STRING,
# MAGIC   branch_manager_first_name STRING,
# MAGIC   branch_manager_last_name STRING,
# MAGIC   number_of_staff INT,
# MAGIC   start_date_branch DATE,
# MAGIC   end_date_branch DATE,
# MAGIC   province STRING
# MAGIC ) PARTITIONED BY(branch_location_city);

# COMMAND ----------

# insert record into the table. Since partitions are defined, data will be inserted into the approriate buckets/partitions.
spark.sql(f"""
INSERT INTO {CATALOG_NAME}.{NEW_SCHEMA_NAME}.BRANCH SELECT * FROM {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.BRANCH
""")

# COMMAND ----------

# Execute the command and notice the partitions in the BRANCH table.
spark.sql(f"""
SHOW PARTITIONS {CATALOG_NAME}.{NEW_SCHEMA_NAME}.BRANCH
""")

# COMMAND ----------

# Execute the following script to partition the MERCHANT table in webagetraining_sandbox_db and save it as partitioned table.
df = spark.read.table(f"{CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.MERCHANT")
df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy("service_category_key").saveAsTable(f"{CATALOG_NAME}.{NEW_SCHEMA_NAME}.MERCHANT")

# COMMAND ----------

# MAGIC %md
# MAGIC # Clean-Up

# COMMAND ----------

# CLEAN-UP: Execute the cell the drop the database and its objects. Don't forget to replace {STUDENT_ID} with the value assigned to you
spark.sql(f"""
DROP SCHEMA {CATALOG_NAME}.{NEW_SCHEMA_NAME} CASCADE
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- verify the new schema is deleted
# MAGIC SHOW SCHEMAS 