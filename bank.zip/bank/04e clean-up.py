# Databricks notebook source
# MAGIC %sql
# MAGIC DROP DATABASE IF EXISTS bank2 CASCADE -- NOTE: Change 2 to your student id

# COMMAND ----------

# MAGIC %md
# MAGIC - delete the job you created as part of the hands-on activity