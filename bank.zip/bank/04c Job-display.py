# Databricks notebook source
CATALOG_NAME = "demo"
SCHEMA_NAME = "bank2" # change 2 to your student id

# COMMAND ----------

spark.sql(f"USE {CATALOG_NAME}.{SCHEMA_NAME}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM TXN

# COMMAND ----------

df_txn = spark.read.table("TXN")

df_txn.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT dc, COUNT(txn_id), AVG(amount)
# MAGIC FROM TXN
# MAGIC GROUP BY dc
# MAGIC ORDER BY AVG(amount) DESC
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import sum,avg,max,count, desc

df_txn = spark.read.table("TXN")

df = df_txn \
  .groupBy(df_txn.dc) \
  .agg(count("txn_id"), avg("amount")) \
  .orderBy(desc("avg(amount)"))

df.display()

# COMMAND ----------

import matplotlib.pyplot as plt

from pyspark.sql.functions import count, avg, desc

# Aggregate
df_txn = spark.read.table("TXN")

df = (
    df_txn.groupBy("dc")
          .agg(count("txn_id").alias("txn_count"),
               avg("amount").alias("avg_amount"))
          .orderBy(desc("avg_amount"))
)

# Convert to Pandas for plotting
pdf = df.toPandas()

# Plot column chart
plt.figure(figsize=(8,6))
plt.bar(pdf["dc"], pdf["avg_amount"], color="skyblue")
plt.xlabel("DC")
plt.ylabel("Average Amount")
plt.title("Average Transaction Amount by DC")
plt.xticks(rotation=45)

# Save to PNG
plt.tight_layout()
plt.savefig("avg_txn_by_dc.png", dpi=150)

plt.show()