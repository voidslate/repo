# Databricks notebook source
# MAGIC %md
# MAGIC # SCD Type 1 and Type 2 Merge Concepts (SQL & Python)
# MAGIC
# MAGIC This notebook demonstrates Slowly Changing Dimension (SCD) Type 1 and Type 2 merge techniques using both SQL and Python (PySpark). We'll use a simple customer scenario where attributes like `name` and `marital_status` may change over time.
# MAGIC
# MAGIC **Sections:**
# MAGIC * SCD Type 1 with SQL
# MAGIC * SCD Type 2 with SQL
# MAGIC * SCD Type 1 with Python
# MAGIC * SCD Type 2 with Python
# MAGIC * Cleanup (drop tables)
# MAGIC
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD Type 1 (SQL): Create Source and Destination Tables
# MAGIC
# MAGIC We'll create two tables:
# MAGIC * `customer_src_scd1`: Source table with new/updated customer data
# MAGIC * `customer_dim_scd1`: Destination dimension table to be updated via SCD1 merge
# MAGIC
# MAGIC Columns: `customer_id`, `name`, `marital_status`

# COMMAND ----------

# DBTITLE 1,Create SCD1 Source Table (SQL)
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE customer_src_scd1 AS
# MAGIC SELECT 1 AS customer_id, 'Alice' AS name, 'Single' AS marital_status UNION ALL
# MAGIC SELECT 2, 'Bob', 'Married' UNION ALL
# MAGIC SELECT 3, 'Charlie', 'Single';

# COMMAND ----------

# DBTITLE 1,Create SCD1 Destination Table (SQL)
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE customer_dim_scd1 AS
# MAGIC SELECT 1 AS customer_id, 'Alice' AS name, 'Married' AS marital_status UNION ALL
# MAGIC SELECT 2, 'Bob', 'Single' AS marital_status UNION ALL
# MAGIC SELECT 4, 'Diana', 'Single';

# COMMAND ----------

# MAGIC %md
# MAGIC Let's view the source and destination tables before the merge.

# COMMAND ----------

# DBTITLE 1,Display SCD1 Source Table
# MAGIC %sql
# MAGIC SELECT * FROM customer_src_scd1;

# COMMAND ----------

# DBTITLE 1,Display SCD1 Destination Table
# MAGIC %sql
# MAGIC SELECT * FROM customer_dim_scd1;

# COMMAND ----------

# MAGIC %md
# MAGIC ### SCD Type 1 Merge (SQL)
# MAGIC
# MAGIC SCD1 overwrites existing records with new values (no history is kept). We'll merge the source into the destination table.

# COMMAND ----------

# DBTITLE 1,Perform SCD1 Merge (SQL)

from pyspark.sql import functions as F

# Read source and destination tables
src = spark.table('customer_src_scd1')
dest = spark.table('customer_dim_scd1')

# Alias columns to avoid ambiguity
src_alias = src.alias('src')
dest_alias = dest.alias('dest')

# Join to update existing records
updated = dest_alias.join(src_alias, dest_alias.customer_id == src_alias.customer_id, 'left') \
    .select(
        dest_alias.customer_id,
        F.coalesce(src_alias.name, dest_alias.name).alias('name'),
        F.coalesce(src_alias.marital_status, dest_alias.marital_status).alias('marital_status')
    )

# Find new records to insert
inserts = src_alias.join(dest_alias, src_alias.customer_id == dest_alias.customer_id, 'left_anti')

# Union updated and inserted records
final_df = updated.unionByName(inserts)

# Overwrite the destination table
final_df.write.mode('overwrite').saveAsTable('customer_dim_scd1')

# COMMAND ----------

# DBTITLE 1,Show SCD1 Destination Table After Merge
# MAGIC %sql
# MAGIC SELECT * FROM customer_dim_scd1;

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD Type 2 (SQL): Create Source and Destination Tables
# MAGIC
# MAGIC We'll create two tables for SCD2:
# MAGIC * `customer_src_scd2`: Source table with new/updated customer data
# MAGIC * `customer_dim_scd2`: Destination dimension table with SCD2 columns: `customer_id`, `name`, `marital_status`, `is_current`, `start_date`, `end_date`
# MAGIC
# MAGIC SCD2 tracks history by closing old records and inserting new ones.

# COMMAND ----------

# DBTITLE 1,Create SCD2 Source Table (SQL)
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE customer_src_scd2 AS
# MAGIC SELECT 1 AS customer_id, 'Alice' AS name, 'Married' AS marital_status UNION ALL
# MAGIC SELECT 2, 'Bob', 'Single' UNION ALL
# MAGIC SELECT 3, 'Charlie', 'Single';

# COMMAND ----------

# DBTITLE 1,Create SCD2 Destination Table (SQL)
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE customer_dim_scd2 (
# MAGIC   customer_id INT,
# MAGIC   name STRING,
# MAGIC   marital_status STRING,
# MAGIC   is_current BOOLEAN,
# MAGIC   start_date DATE,
# MAGIC   end_date DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO customer_dim_scd2 VALUES
# MAGIC   (1, 'Alice', 'Single', true, DATE('2023-01-01'), NULL),
# MAGIC   (2, 'Bob', 'Married', true, DATE('2023-01-01'), NULL),
# MAGIC   (4, 'Diana', 'Single', true, DATE('2023-01-01'), NULL);

# COMMAND ----------

# MAGIC %md
# MAGIC Let's view the SCD2 source and destination tables before the merge.

# COMMAND ----------

# DBTITLE 1,Display SCD2 Source Table
# MAGIC %sql
# MAGIC SELECT * FROM customer_src_scd2;

# COMMAND ----------

# DBTITLE 1,Display SCD2 Destination Table
# MAGIC %sql
# MAGIC SELECT * FROM customer_dim_scd2;

# COMMAND ----------

# MAGIC %md
# MAGIC ### SCD Type 2 Merge (SQL)
# MAGIC
# MAGIC SCD2 tracks changes by closing old records and inserting new ones. Note: MERGE INTO is not supported in this environment, so SCD2 logic is best implemented in Python below.

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD Type 1 (Python): Table Setup and Merge
# MAGIC
# MAGIC We'll demonstrate SCD1 logic using PySpark DataFrame operations. This will overwrite existing records and insert new ones, with no history kept.

# COMMAND ----------

# DBTITLE 1,SCD Type 1 Merge (Python)
# SCD1 merge logic already shown above. Here is a clear, standalone version for reference.
from pyspark.sql import functions as F

src = spark.table('customer_src_scd1')
dest = spark.table('customer_dim_scd1')

src_alias = src.alias('src')
dest_alias = dest.alias('dest')

updated = dest_alias.join(src_alias, dest_alias.customer_id == src_alias.customer_id, 'left') \
    .select(
        dest_alias.customer_id,
        F.coalesce(src_alias.name, dest_alias.name).alias('name'),
        F.coalesce(src_alias.marital_status, dest_alias.marital_status).alias('marital_status')
    )

inserts = src_alias.join(dest_alias, src_alias.customer_id == dest_alias.customer_id, 'left_anti')
final_df = updated.unionByName(inserts)
final_df.write.mode('overwrite').saveAsTable('customer_dim_scd1')

# COMMAND ----------

# DBTITLE 1,Show SCD1 Destination Table After Python Merge
display(spark.table('customer_dim_scd1'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## SCD Type 2 (Python): Table Setup and Merge
# MAGIC
# MAGIC We'll demonstrate SCD2 logic using PySpark DataFrame operations. This will track history by closing old records and inserting new ones.

# COMMAND ----------

# DBTITLE 1,SCD Type 2 Merge (Python)
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import date

# Source and destination tables
src = spark.table("customer_src_scd2").alias("src")
dest = spark.table("customer_dim_scd2").alias("dest")

current_date = date.today().isoformat()

# Current records in destination
current_dest = dest.filter(F.col("is_current") == True)

# Join src and dest to find changed records
joined = current_dest.join(src, current_dest["customer_id"] == src["customer_id"], "inner")

# Detect changes: name or marital_status changed
changed = joined.filter(
    (F.col("src.name") != F.col("dest.name")) |
    (F.col("src.marital_status") != F.col("dest.marital_status"))
)

# Collect IDs of changed customers
changed_ids = [
    row.customer_id
    for row in changed.select(F.col("src.customer_id").alias("customer_id")).distinct().collect()
]

# Close old records in dest
closed = dest.withColumn(
    "end_date",
    F.when(
        (F.col("customer_id").isin(changed_ids)) & (F.col("is_current") == True),
        F.lit(current_date)
    ).otherwise(F.col("end_date"))
).withColumn(
    "is_current",
    F.when(
        (F.col("customer_id").isin(changed_ids)) & (F.col("is_current") == True),
        F.lit(False)
    ).otherwise(F.col("is_current"))
)

# New records for changed customers
new_changed = changed.select(
    F.col("src.customer_id").alias("customer_id"),
    F.col("src.name").alias("name"),
    F.col("src.marital_status").alias("marital_status"),
    F.lit(True).alias("is_current"),
    F.lit(current_date).cast(T.DateType()).alias("start_date"),
    F.lit(None).cast(T.DateType()).alias("end_date")
)

# New records for new customers
new_customers = src.join(current_dest, src["customer_id"] == current_dest["customer_id"], "left_anti")
new_new = new_customers.select(
    F.col("customer_id"),
    F.col("name"),
    F.col("marital_status"),
    F.lit(True).alias("is_current"),
    F.lit(current_date).cast(T.DateType()).alias("start_date"),
    F.lit(None).cast(T.DateType()).alias("end_date")
)

# Combine closed and new records
final_df = closed.unionByName(new_changed).unionByName(new_new)

# Write back to table
final_df.write.mode("overwrite").saveAsTable("customer_dim_scd2")

# COMMAND ----------

# DBTITLE 1,Show SCD2 Destination Table After Python Merge
display(spark.table('customer_dim_scd2'))

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS customer_src_scd1;
# MAGIC DROP TABLE IF EXISTS customer_dim_scd1;
# MAGIC DROP TABLE IF EXISTS customer_src_scd2;
# MAGIC DROP TABLE IF EXISTS customer_dim_scd2;