# Databricks notebook source
CATALOG_NAME = "demo"
SOURCE_SCHEMA_NAME = "bank"
NEW_SCHEMA_NAME = "bank2" # note change 2 to your student id


# COMMAND ----------

spark.sql(f"""
DELETE FROM {CATALOG_NAME}.{NEW_SCHEMA_NAME}.TXN WHERE txn_id NOT IN (SELECT txn_id FROM {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.txn_01_2022_1)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### NO ACTION REQUIRED: This is just for reference
# MAGIC ```sql
# MAGIC -- UPSERT = UPdate + inSERT
# MAGIC -- MERGE INTO `{STUDENT_1}`.TXN AS Target USING (
# MAGIC   SELECT
# MAGIC     *
# MAGIC   FROM
# MAGIC     webagetraining_sandbox_db.txn_01_2022_1
# MAGIC ) AS Source ON (Target.txn_id = Source.txn_id)
# MAGIC WHEN MATCHED THEN
# MAGIC UPDATE
# MAGIC SET
# MAGIC   Target.card_number = Source.card_number,
# MAGIC   Target.date_time = Source.date_time,
# MAGIC   Target.status = Source.status,
# MAGIC   Target.amount = Source.amount,
# MAGIC   Target.dc = Source.dc,
# MAGIC   Target.merchant_key = Source.merchant_key,
# MAGIC   Target.account_key = Source.account_key
# MAGIC   WHEN NOT MATCHED THEN
# MAGIC INSERT
# MAGIC   (
# MAGIC     txn_id,
# MAGIC     card_number,
# MAGIC     date_time,
# MAGIC     status,
# MAGIC     amount,
# MAGIC     dc,
# MAGIC     merchant_key,
# MAGIC     account_key
# MAGIC   )
# MAGIC VALUES
# MAGIC   (
# MAGIC     Source.txn_id,
# MAGIC     Source.card_number,
# MAGIC     Source.date_time,
# MAGIC     Source.status,
# MAGIC     Source.amount,
# MAGIC     Source.dc,
# MAGIC     Source.merchant_key,
# MAGIC     Source.account_key
# MAGIC   )
# MAGIC   ```
# MAGIC   

# COMMAND ----------

spark.sql(f"""
MERGE INTO {CATALOG_NAME}.{NEW_SCHEMA_NAME}.TXN AS Target USING {CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.txn_01_2022_1 AS Source
ON (Target.txn_id = Source.txn_id)
WHEN MATCHED THEN
  UPDATE SET *
WHEN NOT MATCHED THEN
  INSERT *
""")  

# COMMAND ----------

# MAGIC %md
# MAGIC ## OPTIONAL: Merge using PySpark

# COMMAND ----------

from delta.tables import DeltaTable

# Load the target Delta table
target = DeltaTable.forName(spark, f"{CATALOG_NAME}.{NEW_SCHEMA_NAME}.TXN")

# Load the source table as a DataFrame
source = spark.table(f"{CATALOG_NAME}.{SOURCE_SCHEMA_NAME}.txn_01_2022_1")

# Perform the merge
(
    target.alias("Target")
    .merge(
        source.alias("Source"),
        "Target.txn_id = Source.txn_id"
    )
    .whenMatchedUpdateAll()   # equivalent to UPDATE SET *
    .whenNotMatchedInsertAll() # equivalent to INSERT *
    .execute()
)