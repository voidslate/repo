# Databricks notebook source
# MAGIC %sql
# MAGIC -- Execute this script to switch to the training database
# MAGIC USE webagetraining_sandbox_db;

# COMMAND ----------

# MAGIC %md
# MAGIC #### ACTION REQUIRED: Switch to Spark UI and check the following:
# MAGIC - Storage | Verify the TXN table isn't cached. Note: Since you are sharing the cluster with others, there's a chance someone else has already cached it.
# MAGIC - Metrics | check CPU and memory utilization. If they are both maxed out for the majority of the time, you should ask the cluster administrator to increase the cluster capacity

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the query and make a note of the time in seconds it took to run the query. (Note: The time in seconds is displayed at the bottom of the cell. The time will wary depending on the cluster configuration. In the development environment with 8 GB RAM and 4 CPUs, it took 3 seconds to execute this query without caching data.)
# MAGIC SELECT
# MAGIC   b.branch_location_city,
# MAGIC   COUNT(c.client_id)
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC WHERE a.account_type_name LIKE '%TFSA%'
# MAGIC GROUP BY
# MAGIC   b.branch_location_city
# MAGIC ORDER BY
# MAGIC   count(c.client_id) DESC
# MAGIC LIMIT
# MAGIC   1;

# COMMAND ----------

# MAGIC %md
# MAGIC ## ACTION REQUIRED: Do NOT proceed to the next step. Share the time in seconds obtained in the previous step with other participants. After sharing the time in seconds, move on to the next step.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Don't forget to replace {STUDENT_ID} with the actual value.
# MAGIC -- Execute the following query to create a cache named cache_{STUDENT_ID} that caches the same qeury you executed in the previous step.
# MAGIC CACHE TABLE cache_{STUDENT_ID} SELECT
# MAGIC   b.branch_location_city,
# MAGIC   COUNT(c.client_id)
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC WHERE a.account_type_name LIKE '%TFSA%'
# MAGIC GROUP BY
# MAGIC   b.branch_location_city
# MAGIC ORDER BY
# MAGIC   count(c.client_id) DESC
# MAGIC LIMIT
# MAGIC   1;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute the following command to run the query again. Make a note of the of the time shown in seconds below the table result and compare it to the time you noted earlier in this lab.
# MAGIC -- NOTE: You might not have night and day difference in the time since the time difference is better when you have very large datasets (several million records). Also, since you are sharing the environment with other users, so if anyone else has cached the query, you will get to benefit from it too.
# MAGIC -- The time will wary depending on the cluster configuration. In the development environment, with 8 GB RAM and 4 CPUs and caching enabled, it took 0.7 seconds instead of 3 seconds)
# MAGIC SELECT
# MAGIC   b.branch_location_city,
# MAGIC   COUNT(c.client_id)
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN BRANCH b ON b.branch_key = c.branch_key
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC WHERE a.account_type_name LIKE '%TFSA%'
# MAGIC GROUP BY
# MAGIC   b.branch_location_city
# MAGIC ORDER BY
# MAGIC   count(c.client_id) DESC
# MAGIC LIMIT
# MAGIC   1;

# COMMAND ----------

# MAGIC %md
# MAGIC ### ACTION REQUIRED: Switch to Spark UI and see if the cached table shows up

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Replace {STUDENT_ID} with the actual value
# MAGIC -- Execute the following query script to remove the cached data
# MAGIC UNCACHE TABLE cache_{STUDENT_ID}

# COMMAND ----------

# MAGIC %md
# MAGIC #### ACTION REQUIRED: Switch back to Spark UI | Storage and verify the cached data is gone. Note: It might take a minute for the cache to get purged.