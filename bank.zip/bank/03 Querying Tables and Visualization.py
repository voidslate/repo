# Databricks notebook source
# MAGIC %md
# MAGIC # Views, Querying Tables, and Visualizations
# MAGIC - In this lab, you will work on the following features:
# MAGIC   - Views
# MAGIC   - Query tables using SQL and PySpark
# MAGIC   - OOB Visualizations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pre-requisite step

# COMMAND ----------

# change it to your values
CATALOG_NAME = "demo"
SCHEMA_NAME = "bank"

# COMMAND ----------


spark.sql(f"USE {CATALOG_NAME}.{SCHEMA_NAME}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Working with Views using SQL

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- using UNION ALL, get all transactions from txn_01_2022_1 to txn_06_2022_6
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_01_2022_1
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_02_2022_2
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_03_2022_3
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_04_2022_4
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_05_2022_5
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_06_2022_6

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Save the above query as a Temporary View.
# MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_transactions AS (
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_01_2022_1
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_02_2022_2
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_03_2022_3
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_04_2022_4
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_05_2022_5
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   txn_06_2022_6
# MAGIC )
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Execute this cell to get the list of views. Is the view you created temporary?
# MAGIC SHOW VIEWS

# COMMAND ----------

# MAGIC %sql
# MAGIC -- query the newly created view.
# MAGIC SELECT * FROM vw_transactions

# COMMAND ----------

# MAGIC %sql
# MAGIC -- CLEAN-UP: Execute this cell to delete the temporary view you created earlier in this lab. Don't foret to replace {STUDENT_ID} with the value you assigned to you. We don't want to cause unnecessary overload by query all transactions.
# MAGIC DROP VIEW IF EXISTS vw_transactions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Working with Views using PySpark

# COMMAND ----------

# Using PySpark to perform UNION ALL to get all transactions from txn_01_2022_1 to txn_06_2022_6
df_txn1 = spark.sql("SELECT * FROM txn_01_2022_1")
df_txn2 = spark.sql("SELECT * FROM txn_02_2022_2")
df_txn3 = spark.sql("SELECT * FROM txn_03_2022_3")
df_txn4 = spark.sql("SELECT * FROM txn_04_2022_4")
df_txn5 = spark.sql("SELECT * FROM txn_05_2022_5")
df_txn6 = spark.sql("SELECT * FROM txn_06_2022_6")

df = df_txn1 \
  .unionAll(df_txn2) \
  .unionAll(df_txn3) \
  .unionAll(df_txn4) \
  .unionAll(df_txn5) \
  .unionAll(df_txn6)

df.display()

# COMMAND ----------

# Save the above query as a Temporary View.
df.createOrReplaceTempView("vw_transactions")

# COMMAND ----------

# df_view = spark.sql("SELECT * FROM vw_transactions")
df_view = spark.table("vw_transactions")

df_view.display()

# COMMAND ----------

# CLEAN-UP: Execute this cell to delete the temporary view you created earlier in this lab. 
spark.sql("DROP VIEW IF EXISTS vw_transactions")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Querying data using SQL
# MAGIC - In this section of the lab, you will query data using SELECT, WHERE, ORDER BY, and GROUP BY SQL clauses.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- The following query gets customers located in ON from the CUSTOMERS table.
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   CUSTOMER
# MAGIC WHERE
# MAGIC   province = 'ON'

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- From the CUSTOMER table, Get customers who opened their account most recently.
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   CUSTOMER
# MAGIC WHERE
# MAGIC   open_account_date = (
# MAGIC     SELECT
# MAGIC       MAX(open_account_date)
# MAGIC     FROM
# MAGIC       CUSTOMER
# MAGIC   )

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute the following query to get the youngest customers list from the CUSTOMER table.
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   CUSTOMER
# MAGIC WHERE
# MAGIC   dob = (
# MAGIC     SELECT
# MAGIC       MAX(dob)
# MAGIC     FROM
# MAGIC       CUSTOMER
# MAGIC   )

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute the following query to get the average customer age.
# MAGIC SELECT
# MAGIC   AVG(YEAR(current_date()) - YEAR(dob))
# MAGIC FROM
# MAGIC   CUSTOMER 
# MAGIC -- OR: use the following query:
# MAGIC -- SELECT datediff(current_date(), dob)/365 FROM CUSTOMER

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute the following query to get the three provinces whith the least average customer age.
# MAGIC SELECT
# MAGIC   province,
# MAGIC   AVG(YEAR(current_date()) - YEAR(dob)) AS avg_age
# MAGIC FROM
# MAGIC   CUSTOMER
# MAGIC GROUP BY
# MAGIC   province
# MAGIC ORDER BY
# MAGIC   avg_age
# MAGIC LIMIT
# MAGIC   3

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Execute the following query to get the three most popular products based on the amount charged in the txn_01_2022_1 table
# MAGIC SELECT
# MAGIC   p.product_name,
# MAGIC   SUM(txn.amount) AS total_amount
# MAGIC FROM
# MAGIC   PRODUCT p
# MAGIC   INNER JOIN ACCOUNT a ON p.product_key = a.product_key
# MAGIC   INNER JOIN txn_01_2022_1 txn ON a.account_key = txn.account_key
# MAGIC GROUP BY
# MAGIC   p.product_name
# MAGIC ORDER BY
# MAGIC   total_amount DESC
# MAGIC LIMIT
# MAGIC   3

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- TODO: Write a query here to identify what Visa product type most customers own.
# MAGIC SELECT
# MAGIC   a.account_type_name,
# MAGIC   COUNT(a.account_key) account_count
# MAGIC FROM
# MAGIC   CUSTOMER c
# MAGIC   INNER JOIN CLIENTID_ACCOUNT_NUMBER_X_REF_TABLE xref ON c.client_id = xref.client_id
# MAGIC   INNER JOIN ACCOUNT a ON xref.account_key = a.account_key
# MAGIC   INNER JOIN PRODUCT p ON p.product_key = a.product_key
# MAGIC WHERE
# MAGIC   p.product_name = 'Visa Card'
# MAGIC GROUP BY
# MAGIC   a.account_type_name
# MAGIC ORDER BY account_count DESC
# MAGIC LIMIT 1

# COMMAND ----------

# MAGIC %md
# MAGIC # Querying data using PySpark

# COMMAND ----------

# Execute the following script to load CUSTOMER table into DataFrame and display it. (METHOD 1)
# Notice you are specifying the SELECT SQL statement to the sql function

df = spark.sql("SELECT * FROM CUSTOMER")

df.display()

# COMMAND ----------

# Execute the following script to load CUSTOMER table into DataFrame and display it. (METHOD 2)
# Notice you are only specifying the table name to the table function
# Moving forward, it's up to you whether you want to use the sql method or the table method to load a table into Data Frame.

df = spark.read.table(f"{CATALOG_NAME}.{SCHEMA_NAME}.CUSTOMER")

df.display()

# COMMAND ----------

# MAGIC %py
# MAGIC # Execute the following script to only retrieve and display the customer name from the dataframe. The output is sorted by last_name in descending order
# MAGIC from pyspark.sql.functions import desc
# MAGIC
# MAGIC df = spark.sql("SELECT * FROM CUSTOMER")
# MAGIC
# MAGIC df = df.select("first_name", "last_name").orderBy(desc("last_name"))
# MAGIC display(df)

# COMMAND ----------

# MAGIC %py
# MAGIC # Execute the following script to retrieve and display customers who are fulltime employed and are from ON or AB.
# MAGIC
# MAGIC df_customer = spark.read.table(f"{CATALOG_NAME}.{SCHEMA_NAME}.CUSTOMER")
# MAGIC
# MAGIC df = df_customer.filter("(province == 'AB' or province == 'ON') and employment_type = 'fulltime'")
# MAGIC # this can also be written as:
# MAGIC # df = df_customer.filter((df_customer.province == 'AB') | (df_customer.province == 'ON'))
# MAGIC # or like this:
# MAGIC # df = df_customer.filter((df_customer["province"] == 'AB') | (df_customer["province"] == 'ON'))
# MAGIC
# MAGIC display(df)

# COMMAND ----------

# MAGIC %py
# MAGIC # Execute the following code to retrieve and display customer count in each province. It also sorts data by customer count in descending order 
# MAGIC from pyspark.sql.functions import desc
# MAGIC
# MAGIC df = spark.sql("SELECT * FROM CUSTOMER")
# MAGIC
# MAGIC df = df.groupBy("province").count().orderBy(desc("count"))
# MAGIC display(df)

# COMMAND ----------

# MAGIC %py
# MAGIC from pyspark.sql.functions import desc
# MAGIC
# MAGIC df_merchant = spark.sql("SELECT * FROM MERCHANT")
# MAGIC df_txn = spark.sql("SELECT * FROM txn_01_2022_1")
# MAGIC
# MAGIC # Write code here to retreive and display the merchant that has fulfilled most orders based on transactions in txn_01_2022_1
# MAGIC df = df_merchant.join(df_txn, df_merchant.merchant_key == df_txn.merchant_key, how="inner").groupBy("merchant_name").count().orderBy(desc("count")).limit(1)
# MAGIC display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Using the built-in graph/chart options

# COMMAND ----------

# MAGIC %sql
# MAGIC -- You have been provided with the following query
# MAGIC SELECT * FROM CUSTOMER
# MAGIC -- Execute the query and display the following graphs/charts one at a time
# MAGIC -- 1. Using bar chart, identify in what province do most customers reside
# MAGIC -- 2. Using pie chart, identify what percent of the customers have a masters education degree