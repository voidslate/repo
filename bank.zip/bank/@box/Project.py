# Databricks notebook source
# MAGIC %md
# MAGIC # Project
# MAGIC
# MAGIC ## Read through the scenarios and write SQL or PySpark code to answer the question. Time-permitting, you can attempt the questions both in SQL and PySpark.
# MAGIC > Add cells below each question to implement the solution.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pre-requisite: Switch to the Training Database

# COMMAND ----------

# MAGIC %sql
# MAGIC USE webagetraining_sandbox_db

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 1: Answer the following two parts:
# MAGIC - Write a query to display all customers (id, name, and branch location city). Order the customers by client id.
# MAGIC - Visualize the table as Pie Chart breaking down customer count by branch location city.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 2: List customers (id, name, branch location, account type name) who have opened the TFSA account. Sort data by client_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 3: Write a query to retrieve and display the branch location (city) where the most number of TFSA Savings Account are opened by customers.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 4: Write a query to retrieve and display the province where most customers own a credit card.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 5: Name the bank whose Visa Card is most popular in terms of sales amount in the txn_01_2022_1 table

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 6: Answer the following two parts:
# MAGIC - Retrieve and display the 5 branches where the least number of accounts are opened by customers
# MAGIC - Visualize the output as Bar Chart breaking down customer count by branch location city.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Question 7: Answer the following two parts:
# MAGIC - Based on the transaction amount, list 5 debit based products that are least utilized by customers.
# MAGIC - Visualize data using Area Chart breaking down product name by total amount.